# Startpagina

{% hint style="info" %}
Welkom op onze website gewijd aan aan de Algemene Plaatselijke Verordening en het Wetboek. Hier kan je alle informatie vinden die je nodig hebt over de regelgeving.\
\
APV:

[algemene-plaatselijke-verordening](regelgeving/algemene-plaatselijke-verordening/ "mention")\
\
Wetboek:&#x20;

[wetboek](regelgeving/wetboek/ "mention")\
\
Bij vragen of opmerkingen, kun je contact opnemen via de support discord.
{% endhint %}

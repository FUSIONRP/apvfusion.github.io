# Artikel 30 - Crimineel gedrag jegens ambulancemedewerkers en andere overheidsmedewerkers

1. Het is ten strengste verboden om een ambulancemedewerker te ontvoeren. of te vermoorden
2. Het is ten strengste verboden om een ambulancemedewerker te beledigen of niet mee te werken met de roleplay van een ambulancier.
3. Het is niet toegestaan een melding te maken naar een overheids instantie met de intentie om degene die hierop reageert te vermoorden en/of te ontvoeren.
4. Er moeten ten allen tijden 9 overheidsmedewerkers binnen een baan beschikbaar blijven nadat er één ontvoert is, dus als er 10 agenten/KMar lid aanwezig zijn mag er 1 ontvoert worden. geldt per ontvoering
5. Het is niet toegestaan om agenten/KMar te ontvoeren om in beslag genomen goederen terug te eisen, hun overmeesteren daarentegen mag wel.
6. Indien de regel beschreven in lid 2 overtreden wordt zal dit bestraft worden met een straf volgens de 2e categorie. Bij herhaalde overtreding volgt er ten hoogste een straf volgens de 4e categorie.
7. Indien de regel beschreven in lid 3 en 4 overtreden wordt zal dit bestraft worden met een straf volgens de 1e categorie.
8. Per gegijzelde burger mag er maximaal €2.000,- geëist worden van de tegenpartij.
9. Per gegijzelde overheidsmedewerker mag er maximaal €5.000,- geëist worden van de tegenpartij.
10. Hij/zij die zich niet aan lid 5 houdt wordt bestraft volgens de 4e catagorie.
11. Het is niet toegestaan om een gijzeling te doen op HB onder de 20 agenten, pas bij 20 politie/kmar mag HB (politie en kamr) overvallen / gegijzeld worden.
12. Hij/zij die zich niet houdt aan lid 11 wordt bestarft volgens de 1e categorie.

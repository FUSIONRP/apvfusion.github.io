# Artikel 33 - Illegale activiteiten in OOC

1. Het is niet toegestaan om illegale activiteiten te bedrijven in twitter.
2. Onder illegale activiteiten wordt onder andere verstaan, maar niet beperkt tot, het verkopen van locaties waar illegale substanties opgehaald, verwerkt of verkocht kunnen worden, het verkopen en/of verhandelen van (illegale) wapens en in het algemeen handelen in enige goederen waaruit criminelen redelijkerwijs voordeel kunnen halen.
3. Bij overtreding van lid 1 zal er een straf uitgedeeld worden volgens de 1e categorie.
4. Bij herhaalde overtreding zal er een straf van de 2e categorie volgen.

# Artikel 53 - Realistisch pitten

1. Het pitten van een voertuig is toegestaan onder de 100 Km/h.
2. Een pit dient realistisch uitgevoerd te worden, dit houdt dus in dat jij niet met een sports car een SUV van de baan af kan pitten.
3. Het is niet toegestaan een motor te breakchecken, dit valt onder de regel "VDM".
4. Hij/zij die zich niet houdt aan lid 1 2 en 3 zal bestarft worden volgens de 1e catagorie.

# Artikel 39 - Gezichtsbedekking

1. Het is enkel toegestaan om gezichtsbedekkende kleding te dragen in het openbaar, waarneer hier een geldige roleplay achter zit. Overtreding van lid 1 wordt bestraft met een straf in de 1e categorie.

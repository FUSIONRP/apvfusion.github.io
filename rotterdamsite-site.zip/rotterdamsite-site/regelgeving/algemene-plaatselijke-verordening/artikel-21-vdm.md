# Artikel 21 - VDM

1. Hij/zij die op iemand inrijdt met de intentie deze persoon te vermoorden of zijn voertuig bewust als wapen gebruikt, zal gestraft worden volgens de 3e categorie.
2. Hij/zij die op een ander voertuig inrijdt met de intentie te "pitten" met een snelheid hoger dan 100 km/u zal dit worden gezien als onrealistisch en dus gestraft worden volgens de 1e categorie.
3. De overtreding vermeld in het 1e lid en het 2e lid staat bekend als “VDM”.
4. Hij/zij die lid 2 uitvoert met een voertuig dat veel "lichter" of kleiner is als het andere voertuig dat "gepit" word, bijvoorbeeld Sedan vs SUV, zal ook gestraft worden volgens de 1e categorie.

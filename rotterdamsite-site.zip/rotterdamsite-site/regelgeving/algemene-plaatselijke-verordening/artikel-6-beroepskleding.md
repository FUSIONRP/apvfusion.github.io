# Artikel 6 - Beroepskleding

1. Er wordt geacht dat de kleding wordt gedragen die is verstrekt door de baas voor het uitvoeren van het beroep. Wordt dit niet gedaan, zal er gestraft worden met een straf volgens de 2e categorie.
2. Hij/zij die als niet ambtenaar kleding draagt van één van de overheidsbanen zal gestraft worden met een straf volgens de 1e categorie.
3. Onder ambtenaar vallen de mensen in dienst bij één van de volgende instanties:
   * Politie
   * Koninklijke Marechaussee
   * Ambulance
   * ANWB
   * Ministerie van Justitie
   * Taxi

# Artikel 47 - Overvallen

1. Het is niet toegestaan om een juwelier of bank te overvallen zonder er enige roleplay aan te hangen, je mag dus niet enkel een overval plegen en vrije doorgang eisen, zorg dat je een reden hebt waarvoor je de overval pleegt.
2. Bij overtreding van het feit beschreven in lid 1 wordt een straf van de 3e categorie uitgedeeld.
3. Bij het volgend aantal politie agenten en/of KMAR in dienst (opgeteld) mag er een overval plaatsvinden:

* Winkel - 3
* Juwelier - 4
* Grote bank - 6
* Underground heist - 7

4. Het is niet toegestaan om een hit en run te doen, je moet mininimaal 10 minuten wachten voor dat je mag vluchten uit het pand.
5. Hij/zij die zich niet houdt aan lid 4 wordt bestraft volgens de 1e categorie, de buit zal ook ingenomen worden.
6. het is niet toegestaan om je vrienden of mensen uit je eigen netwerk te ontvoeren om te gerbruiken als hostage voor overvallen of gijzelingen
7. Het is niet toegestaan een overval te plegen met een supercar/hypercar.
8. Hij/zij die zich niet houdt aan lid 6 of lid 7 wordt bestraft volgens de 2e categorie.

# Artikel 9 - Combat-logging

1. Hij/zij die tijdens een roleplay moedwillig de game verlaat zonder een geldige reden, zal bestraft worden met een straf volgens de 4e categorie. Bij een time-out/crash dien je binnen 5 minuten weer terug te zijn.
2. Het is de bedoeling als men de game wil verlaten tijdens een roleplay er voor te zorgen dat de mensen die deelnemen aan de roleplay hiervan op de hoogte zijn. Probeer het eerst in voice mee te delen, dan met een “/me” bericht.
3. Nadat de persoon die de roleplay verlaten heeft weer is ingelogd wordt er van deze persoon verwacht de roleplay zo snel mogelijk te hervatten.
4. Onder de overtreding van lid 1 valt ook het vermijden van een roleplay d.m.v. het gebruik van glitches. Val je bijvoorbeeld door de map na het inloggen terwijl je in de cel zit bij het politiebureau wordt er van je geacht je per direct weer te melden op het politiebureau.
5. De periode van 5 minuten, zoals benoemd in lid 1, is bedoeld om een persoon de mogelijkheid te bieden z’n situatie uit te leggen of weer bij zinnen te komen, het is niet de bedoeling hier misbruik van te maken, indien hier misbruik van gemaakt wordt zal er alsnog een straf volgens lid 1 gegeven worden.
6. De overtreding beschreven in lid 1 staat bekend als “Combat Logging”.
7. Hij/zij die zich niet houdt aan artikel 9 zal bestraft worden volgens de 3e catagorie.

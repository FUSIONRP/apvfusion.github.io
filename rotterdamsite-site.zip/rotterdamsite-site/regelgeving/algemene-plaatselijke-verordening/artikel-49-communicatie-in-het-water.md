# Artikel 49 - Communicatie in het water

1. Het is niet toegestaan om je communicatie te gebruiken als je character zich in het water bevind.
2. Bij overtreding van het feit beschreven in lid 1 wordt een straf van de 1e categorie uitgedeeld.

# Artikel 24 - Burgers Overvallen & Oplichten

1. Vorm van oplichting waarbij de criminelen met valse beloften proberen geld te ontvangen van de slachtoffers. Toegestaan tot een bedrag van 5.000,- contant geld.
2. Wanneer jij iets illegaals probeert te kopen of verkopen geldt de bovenstaande regel niet.
3. Het overvallen/oplichten/bestelen van mensen is verboden, dit mag alleen wanneer een persoon bezig is met criminele activiteiten maar ook als spelers bulletproof- en steekvesten/ holsters/ maskers en dergelijke dragen.
4. Het is in geen enkele situatie toegestaan om geld van mensen hun bank te stelen, om te scammen met voertuigen, om spelers te overvallen, te ontvoeren of negatief te bejegenen bij het gemeentehuis of om facturen en/of andere items te stelen van spelers die bezig zijn met een burgerjob.
5. Met criminele activiteiten zoals vermeld in lid 1 worden dingen met betrekking tot drugs, overvallen, witwassen etc bedoeld, en dus geen overtredingen.
6. Bij een overtreding van de wet in lid 1 en/of lid 2 wordt de persoon gestraft volgens de 3e categorie en wordt het geld teruggegeven aan het slachtoffer. Wanneer de persoon het geld al heeft uitgegeven zal het resulteren in straf van de 3e categorie.
7. Hou hiermee wel rekening dat het bij het vergrijp zoals beschreven in lid 1 niet de bedoeling is hiermee misbruik te maken van onwetendheid van mensen, dus vermijd het oplichten van nieuwe spelers.
8. Het is voor criminelen toegestaan om mensen gedurende langere tijd te ondervragen en/of te martelen. Echter mag dit maximaal circa 2 uur duren. Er dient ook goede roleplay aan gekoppeld te worden. Dit is ter beoordeling aan een stafflid.
9. Bij een overtreding van de regel in lid 8 wordt de persoon gestraft volgens de 1e categorie en zal het scenario onmiddellijk worden teruggedraaid.
10. Wanneer je iemand fouilleert maak je dit ten alle tijden kenbaar.
11. Je bent zelf verantwoordelijk om te checken of er de juiste tunes op je voertuig zitten, wanneer jij deze overkoopt van een andere burger.
12. Onjuist wapengebruik bij overvallen zal bestraft worden. Dit is ter beoordeling van een stafflid.

# Artikel 31 - Roleplay & Ledenaantal Criminele Organisaties

1. Criminele organisaties mogen een maximaal ledenaantal hebben van 25 personen.
2. Een roleplayscenario van/met een criminele organisatie mag maximaal bestaan uit 25 personen, inclusief de leden van de criminele organisatie zelf. Dit houdt dus in dat iedereen die op dat moment enige medewerking verleent aan de criminele organisatie, ook indien zij officieel niet tot de criminele organisatie behoren, tot dit aantal wordt gerekend.
3. Overtreding van het ledenaantal genoemd in lid 1 & 2 zal een straf worden uitgedeeld volgens de 1e categorie aan de eigena(a)r(en) & deelnemers van de organisatie.
4. Bij herhaalde overtreding zal een individuele waarschuwing volgen.

# Artikel 8 - Spam

1. Hij/zij die in welk middel dan ook meer dan 3 berichten per 10 seconden of 10 berichten per 60 seconden stuurt, zal bestraft worden met een straf volgens categorie 3.
2. Indien dit bij meldkamers wordt gedaan zal de straf verhoogd worden naar een straf volgens categorie 6.
3. De overtreding beschreven in lid 1 staat bekend als “spam”.

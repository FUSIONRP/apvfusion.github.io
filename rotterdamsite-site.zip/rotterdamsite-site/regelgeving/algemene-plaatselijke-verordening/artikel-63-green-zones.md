# Artikel 63 - Green Zones

1. Het is niet toegestaan om mensen te liquideren, overvallen of te gijzelen in een greenzones.
2. De hieronder genoemde locaties zijn greenzones:

* Het gemeentehuis.
* Het ziekenhuis.
* De ANWB.
* De Basic-Fit.

3. Het is niet toegestaan om de aangegeven greenzones in te vluchten tijdens een scenario.

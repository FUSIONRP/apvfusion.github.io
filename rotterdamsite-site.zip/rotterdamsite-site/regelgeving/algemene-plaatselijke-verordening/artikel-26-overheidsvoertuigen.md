# Artikel 26 - Overheidsvoertuigen

1. Je mag als je geen ambtenaar in dienst bent geen overheidsvoertuigen besturen, tenzij de roleplay dit toelaat.
2. Overheidsvoertuigen mogen enkel gestolen worden als laatste redmiddel en/of met een geldige roleplay reden.
3. Het is de bedoeling nadat je het voertuig hebt gestolen om deze zo snel mogelijk te dumpen.
4. Hij/zij die zich schuldig maakt aan het stelen van overheidsvoertuigen als beschreven in lid 1 zal bestraft worden met een straf volgens categorie 1 dit is ter beoordeling van het desbetreffende stafflid.

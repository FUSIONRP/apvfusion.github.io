# Artikel 38 - Bodycams

1. Bodycam beelden zijn op de volgende manier toegestaan:

* Overheidsdiensten zijn uitgerust met bodycams.
* Burgers kunnen alleen met hun telefoon filmen, hun mogen een bodycam gebruiken maar deze moet zichtbaar zijn in de roleplay mocht het gerechtelijk gebruikt mogen worden.
* De voertuigen van de overheidsdiensten zijn uitgerust met een 360 graden camera.
* Overige voertuigen zijn uitgerust met een dashcam gericht naar achteren en voren.

2. De voorbeelden benoemd in lid zijn bedoeld in de context van Roleplay. Voor bewijsvoering in een ticket of report is alle beeldmateriaal toegestaan.
3. Hij/zij die zich niet houdt aan lid 1 en 2 wordt bestraft volgense de 2e catagorie.

# Artikel 61 - Off-road voortuigen

1. Het is niet toegestaan om met een on-road voertuig, off-road te rijden.
2. Hij/zij die zich niet aan lid 1 houdt wordt bestraft volgense de 1e catagorie
3. Enkele voertuigen zijn uitgezonderd, deze mogen wel off-road rijden. Hieronder zijn alle voertuigen benoemd welke uitgezonderd zijn:

<table><thead><tr><th>Volledig Off-Road</th><th>Onverharde Wegen</th><th data-hidden></th><th data-hidden></th></tr></thead><tbody><tr><td>Mercedes G65 AMG  </td><td>Brabus G900</td><td></td><td></td></tr><tr><td>Dodge RAM </td><td>Range Rover SVR Mansory</td><td></td><td></td></tr><tr><td>Ford Raptor</td><td>Brabus G800</td><td></td><td></td></tr><tr><td>Jeep Gladiator</td><td>Tractor</td><td></td><td></td></tr><tr><td>BMW X5(M)</td><td>Audi E-Tron SUV</td><td></td><td></td></tr><tr><td>Bronco</td><td>Audi SQ7</td><td></td><td></td></tr><tr><td>Jeep Rubicon</td><td>Cadillac Escalade 2021</td><td></td><td></td></tr><tr><td>Volkswagen Amarok</td><td>Mercedes GLE 53 AMG coupe</td><td></td><td></td></tr><tr><td>Mercedes X-Klasse</td><td>Mercedes GLS63 AMG</td><td></td><td></td></tr><tr><td>Ford F450</td><td>Mercedes GLE63S</td><td></td><td></td></tr><tr><td></td><td>Audi RSQ8</td><td></td><td></td></tr><tr><td></td><td>Porsche Cayenne</td><td></td><td></td></tr><tr><td></td><td>Mercedes GLS800</td><td></td><td></td></tr></tbody></table>


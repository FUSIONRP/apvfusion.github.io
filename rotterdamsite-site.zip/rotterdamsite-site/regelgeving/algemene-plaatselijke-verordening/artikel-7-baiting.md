# Artikel 7 - Baiting

1. Hij/zij die moedwillig ambtenaren uitlokt met de intentie deze te irriteren en/of bezig te houden zal bestraft worden met een straf volgens de 2e categorie.
2. De overtreding zoals beschreven in lid 1 staat bekend als “cop-baiting”.
3. Hij/zij die moedwillig burgers uitlokt met de intentie deze te irriteren en/of bezig te houden zal bestraft worden meteen straf volgends de 2e categorie.

# Artikel 59 - KVK Verguningen

1. Het is verplicht om als ondernemer je in te schrijven bij de KVK.
2. Het is niet toegestaan om zonder vergunning een bedrijf te runnen.
3. Hij/zij die zich niet houdt aan lid 1 en 2 wordt bestraft volgende de 1e catagorie.

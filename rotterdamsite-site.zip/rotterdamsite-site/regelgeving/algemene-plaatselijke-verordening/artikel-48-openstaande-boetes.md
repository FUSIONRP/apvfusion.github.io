# Artikel 48 - Openstaande boetes

1. Openstaande boetes worden automatisch na 24 uur van je rekening gehaald tegen een meerprijs.

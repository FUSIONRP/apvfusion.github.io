# Artikel 57 - Server restarts

1. Het is niet toegestaan om 15 minuten voor een server restart een overval, of een gijzeling te starten.
2. Het is niet toegestaan om 15 minuten voor een server restart een burger te overvallen / beroven van zijn goederen. Dit geldt niet wanneer de actie al ingzet is voor de 5 minuten aankondiging.
3. Hij/zij die zich niet houdt aan lid 1 zal bestarft worden volgens de 1e catagorie.

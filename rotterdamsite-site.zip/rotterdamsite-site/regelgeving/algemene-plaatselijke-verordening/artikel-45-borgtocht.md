# Artikel 45 - Borgtocht

1. Op het moment dat een persoon op borgtocht wordt gestuurd door de politie, dan ligt het scenario tussen de politie en de desbetreffende persoon stil.
2. Er dient aan alle voorwaarden van de borgtocht gehouden te worden.
3. Het is niet toegestaan om spullen (zoals wapens, drugs en dergelijke) die vóór de aanhouding in het appartement/voertuig zaten hieruit te halen of over te dragen naar andere personen op het moment dat een persoon op borgtocht is gestuurd.
4. Bij overtreding van lid 1, 2 of 3 zal een straf worden gegeven van de 5e categorie en zal het roleplayscenario worden teruggedraaid.

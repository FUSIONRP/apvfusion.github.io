# Artikel 58 - Realistisch voertuiggebruik

1. Het is niet toegestaan om met een hypercar criminele activiteiten uit te voeren.
2. Lid 1 komt te vervallen wanneer jij in een activiteit wordt getrokken, hierdoor mag je reageren op de situatie. Echter dien je het voertuig naderhand weg te zetten.
3. Hij/zij die zich niet houd aan lid 1 zal bestarft worden volgens de 1e catagorie

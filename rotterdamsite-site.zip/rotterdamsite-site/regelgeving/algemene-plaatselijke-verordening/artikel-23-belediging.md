# Artikel 23 - Belediging

1. Hij/zij die scheldt met hedendaags relevante ziektes (kanker en dergelijke) of met racistische opmerkingen, of andere ongepaste opmerkingen, wordt gestraft met een straf volgense de 7e catagorie
2. Hij/zij die doelbewust een vrouw uitscheld met hedendaagse uitspraken en andere aanstootgevende uitspraken.
3. Hij/zij die in een andere taal een vrouw (extreem) uitscheldt
4. Hij/zij die sexistische opmerking maakt richting een vrouw
5. Als je een vrouw zonder echte reden uitscheld en puur omdat het een vrouw is resulteert dit in een ban van categorie 4. In extreme gevallen kan dit resulteren in een categorie 6. Herhaaldelijks deze fout maken resulteert in een categorie 7.
6. Hij/zij die iemand beledigt op een milde manier ( wordt bepaald door een staflid ) wordt bestraft volgens de 4 catagorie

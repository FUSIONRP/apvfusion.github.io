# Artikel 44 - Voertuigverlies in water (bij achtervolging)

1. Wanneer men een voertuig dumpt tijdens een achtervolging, waar bij deze in het water terecht komt, zal deze 7 dagen in beslag genomen worden, waarna er 20% van de nieuwprijs voor moet worden betaald om het voertuig weer op te halen.

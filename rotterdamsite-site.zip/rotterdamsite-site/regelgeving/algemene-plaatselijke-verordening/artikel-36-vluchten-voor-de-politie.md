# Artikel 36 - Vluchten voor de politie

1. Het is toegestaan om te vluchten voor de politie doormiddel van jouw voertuig het water in te rijden maar enkel met gepaste snelheid.
2. Het overtreden van de bovenstaande regel zal worden bestraft worden met een straf van de 3e categorie.

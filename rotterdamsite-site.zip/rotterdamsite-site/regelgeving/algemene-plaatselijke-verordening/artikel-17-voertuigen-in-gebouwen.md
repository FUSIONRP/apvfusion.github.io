# Artikel 17 - Voertuigen in gebouwen

1. Het is niet toegestaan met voertuigen gebouwen te betreden die daar niet voor bedoeld zijn.
2. Bij het overtreden van de regel beschreven in lid 1 zal dit bestraft worden met een straf volgens de 2e categorie.

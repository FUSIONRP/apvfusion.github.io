# Artikel 11 - Value Of Life

1. Hij/zij die geen waarde hecht aan het leven van zijn karakter zal gestraft worden volgens de 3e categorie.
2. De overtreding zoals beschreven in lid 1 staat bekend als “no value of life”.
3. Enkele voorbeelden hiervoor zijn:
   * Zodra iemand een pistool op je richt binnen 50 meter en er geen beschutting is, blijf je staan, werk je mee en val je deze persoon niet aan.
   * Zodra iemand een mes trekt binnen arm lengte van je werk je mee, doe je dit niet ben je niet zuinig met je leven aangezien je dat bewust het risico neemt neergestoken te worden.
   * Met een helikopter vlak boven de grond zweven om goederen en/of personen te transporteren.
   * Elke andere vorm waarmee je bewust je eigen leven in een té groot gevaar brengt valt onder no value of life, dus gebruik je gezonde verstand om de situatie in te schatten.
   * Zodra een persoon een wapen in zijn hand heeft en jij gaat hem proberen te boeien of richting hem te rennen word dit gezien als no value of life.
   * Wanneer je getaserd of beschoten bent dien jij je over te geven.
   * De beslissing van een stafflid betreft alle bovenstaande en overige situaties is altijd leidend.

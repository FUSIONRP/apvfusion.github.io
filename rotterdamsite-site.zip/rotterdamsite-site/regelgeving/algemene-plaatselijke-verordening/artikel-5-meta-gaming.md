# Artikel 5 - Meta-gaming

1. Informatie verkregen buiten het karakter om (alle informatie die niet verkregen is door jouw karakter binnen FiveM) mag niet gebruikt worden door het karakter.
2. Het feit beschreven in lid 1 staat bekend als “meta-gaming”.
3. Indien de regel in lid 1 overtreden wordt wordt dit bestraft met een straf volgens de 3e categorie.
4. Voor communicatie over lengte in game kun je een telefoon en/of portofoon gebruiken welke je in de telefoon winkel kunt kopen.
5. Bij het gebruik van een portofoon-systeem in welke vorm dan ook dient de persoon die praat ook ingame te horen te zijn.
6. Het niet naleven van het feit beschreven in lid 5 staat eveneens bekend als "meta-gaming" en zal worden bestraft worden met een straf van de 3e categorie.
7. Het is verboden om in (externe) discord calls te zitten met iemand die ook in de stad aanwezig is.
8. Het overtreden van lid 7 zal resulteren in een straf van minimaal de 3e categorie.
9. Ten behoeve van het handhaven van dit artikel is een stafflid bevoegd om beelden op te vragen van de persoon die verdacht wordt van het overtreden van lid 7. Indien de speler dit niet kan, dan volgt er een straf volgens lid 3.

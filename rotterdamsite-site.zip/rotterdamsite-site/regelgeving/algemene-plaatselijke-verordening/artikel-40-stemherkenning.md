# Artikel 40 - Stemherkenning

1. Het is niet toegestaan om een speler te herkennen aan zijn/haar stem, zolang hij zijn gezicht heeft bedekt.
2. Het overtreden van de feiten beschreven in dit artikel zullen worden gestraft met een straf van de 2e categorie.

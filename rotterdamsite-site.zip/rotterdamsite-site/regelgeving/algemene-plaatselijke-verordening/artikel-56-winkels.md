# Artikel 56 - Winkels ( nog niet van toepassing )

1. Het is niet toegestaan om meerdere winkels op je naam te hebben, dit geldt per persoon.
2. Het is niet toegestaan om je producten in te kopen bij een andere winkel, je dient zelf je producten binnen te krijgen voor je eigen markt.
3. Het is niet toegestaan om met opzet een winkel leeg tekopen, zodat deze weer door het systeem te koop komt te staan.
4. Hij/zij die zich niet houdt aan lid 1 2 en 3 zal bestarft worden volgens de 1e catagorie.

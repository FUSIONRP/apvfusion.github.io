# Artikel 13 - Microfoon

1. U dient een werkende microfoon te hebben in-game. Indien een persoon moedwillig weigert hieraan te voldoen zal Hij/zij bestraft worden volgens de 2e categorie.
2. Voordat de straf zoals beschreven in lid 1 gegeven wordt zal een stafflid er alles aan doen contact te vinden met de desbetreffende persoon, door onder andere gebruik te maken van de in-game voice chat, ooc, /me en eventueel discord. Reageert de persoon op al deze middelen niet dan zal de persoon gekicked worden met de reden “We horen u niet, probeer aub uw microfoon werkend te maken.”

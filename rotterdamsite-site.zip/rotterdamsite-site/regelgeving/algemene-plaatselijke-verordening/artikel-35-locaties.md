# Artikel 35 - Locaties

1. Het is niet toegestaan om algemene locaties te campen met de intentie om te beroven.
2. Het overtreden van de bovenstaande regels zal worden bestraft worden met een straf van de 2e categorie.

# Artikel 50 - Donatie voertuigen

1. Het is niet toegestaan om je de donatie voertuigen te verkopen of om hem weg te geven.
2. Bij overtreding van het feit beschreven in lid 1 wordt een straf van de 6e categorie uitgedeeld en is het mogelijk dat de auto permanent wordt verwijderd uit jouw bezit.

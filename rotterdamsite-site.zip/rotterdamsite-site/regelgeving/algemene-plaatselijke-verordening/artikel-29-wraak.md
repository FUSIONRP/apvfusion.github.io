# Artikel 29 - Wraak

1. Het is nadat iemand van het leven beroofd is door een rivaliserende groep, gedurende 24 uur niet toegestaan mee te doen aan eventuele wraakacties tegen deze groep.
2. Nadat jij bent overvallen, beschoten of lastig bent gevallen, heb jij 24 uur de tijd om revange te nemen op de daders. Na de 24 uur vervalt dit recht en mag je geen revange meer nemen op het gebeurde scenario. LET OP: Dit houdt niet in dat er zonder confirmatie, en/of zonder contact persoon geliquideerd mag worden. Er dient dus wel roleplay aan vast te hebben gezeten.
3. Lid 2 komt te vervallen als jij al van het leven bent beroofd door de rivaliserende groep volgens lid 1.
4. Indien de regel zoals beschreven in lid 1 overtreden wordt zal dit bestraft worden met een straf volgens de 3e categorie.

# Artikel 52 - Aanvragen van refunds

1. Je dient de gehele scenario op clip te hebben. Mocht een stafflid een langere clip willen, dien je dit ook op te sturen.
2. Het is verplicht om in je clip te laten zien welke ID's van burgers betrokken zijn bij het scenario.
3. Het is verplicht je bestand te uploaden en ons een link te sturen in jouw ticket. Onbetrouwe bronnen openen wij niet. Gebruik hiervoor dan ook: Medal of YouTube.
4. Je dient binnen 10 minuten de template in te vullen.
5. Het minimale bedrag voor een refund is 10.000,- euro.
6. Het is verplicht om direct je clip in te voegen.
7. Indien je refund niet voldoet aan een van de bovenstaande eisen, wordt de ticket direct gesloten.

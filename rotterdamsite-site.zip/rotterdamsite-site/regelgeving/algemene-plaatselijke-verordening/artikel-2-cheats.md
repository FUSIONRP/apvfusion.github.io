# Artikel 2 - Cheats

1. Hij/zij die gebruik maakt van software/hulpmiddelen (cheats) van derde partijen om profijt te krijgen in het spel zal bestraft worden volgens de 7e categorie.
2. Enkele voorbeelden hiervan zijn, onder andere, een crossair en/of cheats.
3. Het beheer kan na het zien van eventueel beeldmateriaal een stemmingsronde houden om te beslissen of iemand gebruikt heeft gemaakt van software/hulpmiddelen (cheats) van derde partijen, en mag op basis hiervan een straf namens de 7e categorie uitdelen.

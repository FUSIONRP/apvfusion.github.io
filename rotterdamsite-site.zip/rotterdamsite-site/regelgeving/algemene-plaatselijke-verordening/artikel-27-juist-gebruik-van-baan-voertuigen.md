# Artikel 27 - Juist gebruik van baan voertuigen

1. Er wordt geacht van mensen geen gebruik te maken van baan voertuigen voor illegale bezigheden.
2. Het is verplicht om voor het uitvoeren van je baan het voertuig te gebruiken dat is verstrekt door de baas.
3. Hij/zij die de regel zoals beschreven in lid 1 en/of 2 overtreed zal bestraft worden met een straf volgens de 2e categorie, hiernaast zal de overtreder ontslagen worden en deze persoon mag dit beroep een week lang niet uitvoeren.

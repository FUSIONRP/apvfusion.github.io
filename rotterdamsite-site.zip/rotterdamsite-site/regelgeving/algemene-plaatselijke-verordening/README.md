# Algemene Plaatselijke Verordening

Hier vind je de APV met alle server regels die worden gehanteerd in Rotterdam. We vragen je deze te lezen om een eerlijke en betere ervaring te krijgen in onze server.

{% hint style="info" %}
&#x20;De Algemene Plaatselijke Verordening kan ten alle tijden aangepast worden door het Staff Team.
{% endhint %}

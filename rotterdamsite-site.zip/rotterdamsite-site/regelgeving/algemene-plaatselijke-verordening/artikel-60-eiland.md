# Artikel 60 - Eiland

1. Het is toegestaan om op het gehele eiland mensen te overvallen.
2. Het is niet toegestaan om op pluk locaties te mogen campen.
3. Hij/zij die zich niet houdt aan lid 1 en 2 wordt bestraft volgens de 2e catagorie.

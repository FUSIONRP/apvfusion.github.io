# Artikel 14 - Nederlandse Taal

1. Er wordt van spelers verwacht de Nederlandse en/of Engelse taal te beheersen. Indien iemand de Nederlandse en/of Engelse taal niet beheerst is deze persoon niet welkom op de server.
2. Andere talen dan het Nederlands en het Engels mogen niet gebruikt worden op een provocerende of beledigende manier gedurende de roleplay.
3. Bij een overtreding van de regel in lid 2 wordt de overtreder bestraft met een bestraffing van de 1e categorie.

# Artikel 1 - FailRP & Powergaming

1. Hij/zij die opzettelijk een roleplay van zeer slechte kwaliteit uitspeelt wordt gestraft volgens de 3e categorie.
2. De overtreding vermeld in het eerste lid staat bekend als “FailRP”.
3. Hij/zij die opzettelijk de roleplay zodanig vormt dat er een oneerlijke of onrealistische draai aan het verhaal geeft, of de roleplay van de andere partij zelf invult door een onrealistische dwang, wordt gestraft volgens de 3e categorie.
4. De overtreding vermeld in het derde lid staat bekend als "powergaming"
5. Het is niet toegestaan om meerdere handelingen in een keer uit te voeren via /me
6. Hij/zij die zich niet houdt aan lid 5 zal gestarft worden volgense de 1e categorie
7. Het is niet toegestaan om met een lekke band te blijven rijden.
8. Hij/zij die zich niet houdt aan lid 7 zal bestarft worden volgens de 1e categorie
9. Als je gecrasht bent in een scenario mag je niet meer verder rijden.
10. Hij/zij die zich niet houdt aan lid 9 en 11 houdt wordt bestraft volgens de 2e categorie.
11. Het is niet toegestaan om tijdens achtervolging een voertuig uit je garage te halen, indien je uit het zicht bent is dit wel toegestaan.
12. De overtreding vermeld in lid 11 zal bestraft worden volgens de 1e categorie.
13. Enkele voorbeelden van lid 1 en lid 3 zijn: \
    Proberen "loopholes" te vinden in de regels en/of de regels te misbruiken voor je eigen voordeel:
    * In het water zwemmen voor een onrealistisch lange tijd;
    * In een portofoon praten terwijl je aan het zwemmen bent of onderwater bent;
    * Een agent ontvoeren om een signalering te verwijderen of om iets te bekijken in het politiesysteem (MEOS);
    * Stelen van een voertuig van een burger zonder enige geldige reden;
    * Emotes spammen of ongepaste emotes gebruiken tijdens een serieus roleplayscenario;
    * &#x20;Je voertuig als gestolen melden bij de politie of koninklijke marechaussee, terwijl dit niet het geval is;
    * Het spelen op een zodanige resolutie dat er redelijkerwijs van uit kan worden gegaan dat hier voordeel uit wordt gehaald;&#x20;
    * Het hebben van keybinds voor /me Geen roleplay aangaan na of je niets aantrekken van een (ernstige) verwonding of (verkeers)ongeval;
    * Iemand in een auto meedragen d.m.v. /carry.

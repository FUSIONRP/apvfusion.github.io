# Artikel 55 - Samenwerkingen tussen officiële groepen

1. Het is toegestaan om in een scenario samen te werken met een andere officiële groepering.
2. Dit mag maximaal met 1 andere officiële groepering. Het maximale per scenario is 25, waarvan er maximaal 10 van een andere groepering mag zijn.
3. Officiële gangs mogen wel te alle tijden samenwerken met onofficiële groeperingen. Het maximale per scenario is 25, waarvan er geen maximale staat op de andere groepering.
4. Hij/zij die zich niet houdt aan lid 1 wordt bestarft met een gang strike.

# Artikel 10 - Deelname aan het verkeer

1. Er wordt van personen geacht realistisch rijgedrag aan te houden. Dus niet met circuit auto’s door de woestijn heen rijden met 100 km/u.
2. Overtredingen van lid 1 worden bestraft met een straf van de 1e categorie.
3. Buiten de weg rijden mag, mits dit met matige snelheid gedaan wordt en met een geschikt voertuig, pas hierbij dus ook de snelheid aan voor het type voertuig. De geschikte voertuigen staan omschreven in Artikel 61 - Off-road voertuigen.
4. De overtreding zoals beschreven in lid 1 staat bekend als “GTA driving”.

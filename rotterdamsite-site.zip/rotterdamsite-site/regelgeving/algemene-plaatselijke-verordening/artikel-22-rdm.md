# Artikel 22 - RDM
  1. Hij/zij die zonder een geldige reden een persoon moedwillig van het leven beroofd/verwond zal gestraft worden volgens de 3e categorie.
  2. Hij/zij die zonder een geldige reden een dier moedwillig van het leven beroofd/verwond zal gestraft worden volgens de 3e categorie.
  3. Deze straf kan meerdere malen gegeven worden indien er meer dan één persoon van het leven beroofd is.
  4. Het is niet toegestaan om driveby's te plegen. Even snel uitstappen, iemand doodschieten en wegrijden.
  5. De overtreding vermeldt in het eerste en derde lid staat bekend als “RDM”.
  6. Indien de andere partij meewerkt tijdens dat persoon wordt overvallen, mag de desbetreffende persoon niet van zijn leven worden beroofd. 
  7. Hij/zij die zich niet aan lid 5 houdt wordt bestraft volgens de 3e catagorie.



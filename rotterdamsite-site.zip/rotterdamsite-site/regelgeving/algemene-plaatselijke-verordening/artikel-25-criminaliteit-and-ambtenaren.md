# Artikel 25 - Criminaliteit & Ambtenaren

1. Voor een ambtenaar is het niet toegestaan zich bezig te houden met illegale bezigheden (corruptie).
2. U bent als ambtenaar als je werkzaam bent voor overheidsdiensen (Politie, Kmar, Ambulance, ANWB, Openbaar Ministerie, Nieuwsmedewerker en Makelaar).
3. Indien een persoon de regel zoals beschreven in lid 1 overtreed wordt deze bestraft met een straf volgens categorie 6 en zal deze persoon ontslagen worden en deze persoon dit beroep twee weken lang niet uitvoeren.
4. Verder is het niet toegestaan om door de politie in beslag genomen objecten door te handelen naar spelers. Ditzelfde is ook van toepassing op alle andere overheids objecten.
5. Bij een overtreding van de regel in lid 4 wordt de overtreder ontslagen en hiernaast bestraft volgens de 6e categorie.
6. Onder overheidsobjecten vallen voorwerpen zoals: medkits, repair kits, zaklamp, politie geweren, enzovoort.
7. Een ambtenaar buiten dienst mag geen politie wapens bij zich dragen deze dienen ten alle tijden na een dienst opgeborgen te worden in de wapenkluis. Bij overtreding van dit lid zal er gestraft worden volgens de 1e categorie.
8. Op lid 7 geldt een uitzondering voor zogenoemde DSI leden "Dienst Speciale Interventies" en de leden van de BOT "bijzonder ondersteunings team"deze leden mogen wel hun wapens buiten dienst behouden.

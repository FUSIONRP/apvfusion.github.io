# Artikel 20 - Combatstashen

1. Het is verboden om binnen de 10 minuten nadat je voor het laatst een criminele activiteit deed (drugs, schieten met wapen, ...) iets op te bergen in je appartement/kofferbak.
2. Het is verboden om tijdens je overheidsdienst inbeslaggenomen wapens/drugs/auto's binnen de 10 minuten na dat je het wapen hebt geconfisqueerd te vernietigen.
3. Het feit genoemd in lid 1 en lid 2 wordt gezien als "Combatstashen".
4. Dit zal gestraft worden met een straf van de 2e categorie.

# Artikel 62 - Tickets

1. Beeldmateriaal onder de 5 minuten, worden niet in behandeling genomen.
2. Het scenario dient binnen 48 uur afgespeeld te zijn.
3. Indien je ticket niet voldoet aan een van de bovenstaande eisen, wordt de ticket direct gesloten.

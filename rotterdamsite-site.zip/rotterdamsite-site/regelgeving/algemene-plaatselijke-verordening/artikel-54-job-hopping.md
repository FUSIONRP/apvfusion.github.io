# Artikel 54 - Job hopping

1. Het is niet toegestaan om binnen 7 kalender dagen te wisselen tussen overheidsinstanties.
2. Het is niet toegestaan om binnen 7 kalender dagen te wisselen tussen criminele organisaties.
3. Het is niet toegestaan om binnen 7 kalender dagen te wisselen tussen criminele organisaties en overheidsinstantie.
4. Hij/zij die zich niet houdt aan lid 1 2 en 3 wordt bestraft volgens de 1e catagorie en moet 2 maanden wachten voordat die aangenomen mag worden.

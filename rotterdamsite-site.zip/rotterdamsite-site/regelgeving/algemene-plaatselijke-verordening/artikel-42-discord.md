# Artikel 42 - Discord

1. Het is niet toegestaan om externe discords te gebruiken voor roleplay gerelateerde zaken.
2. Wanneer je met meerdere mensen die op Rotterdam spelen in een voice call zit is streamen niet toegestaan en moet je gedeafened en gemute zijn, de andere gebruikers in die call mogen niet in deze roleplay vermengt zijn. Dit is alleen toegestaan met toestemming van een stafflid.
3. Het overtreden van het feit genoemd in lid 1 of 2 zal resulteren in een straf van de 4e categorie.

# Artikel 51 - Wapen vs Wapen

1. Het is niet toegestaan om een wapen te pakken wanneer er een wapen wordt gericht tegen jou. Dit houdt in dat als er een wapen in het spel is, jij jezelf niet kan beschermen d.m.v. zelf een wapen te trekken.
2. Een melee wapen is ten allen tijde ondergeschikt aan een vuurwapen tenzij:
  * Je meldt dat het meleewapen (Mes/vlindermes/machete) zich tegen de keel bevindt.
  * Je met een (Mes/vlindermes/machete) binnen armlengte van je slachtoffer bevindt.
4. Wanneer jij wordt gefouilleerd is het niet toegestaan om zelf een wapen te trekken op persoon die jou op dat moment fouilleerd.
5. Bij overtreding van het feit beschreven in lid 4 zal bestraft worden met een straf volgens de 3e categorie.
6. Bij overtreding van het feit beschreven in lid 1 gaat het om een vuurwapen dat gericht moet staan binnen 20 meter en een slag/ steek wapen binnen 3 meter.
7. Bij overtreding van het feit beschreven in lid 1 wordt een straf van de 2e categorie uitgedeeld.

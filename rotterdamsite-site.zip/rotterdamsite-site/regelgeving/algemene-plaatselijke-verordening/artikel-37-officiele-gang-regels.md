# Artikel 37 - Officiële gang regels

1. Probeer ten alle tijden te voorkomen om te schieten bij een officieel gang huis.
2. Het is verboden om nep meldingen te maken in de omgeving van een ganghuis met de intentie tot uitlokken van de criminelen of het in de problemen werken van de rivaliserende groep.
3. Op het moment dat een voertuig in beslag genomen wordt en in een opslag gezet wordt is het niet toegestaan om deze nog uit je garage te halen.
4. Wanneer er 2 weken lang geen roleplay aan de inbeslagname gebonden word is het toegestaan om het voertuig weer gratis uit de garage te halen.
5. Een gangoorlog kan verklaard worden door een van de 2 groepen (door gangbazen) wanneer daar een goede reden voor is. een oorlog is afgelopen wanneer:
   * Hij langer dan 1 week geduurd heeft.
   * Alle leden eenmaal zijn overleden.
   * Wanneer één van de 2 groepen zich overgeeft.
6. Het overtreden van lid 1,2,3 of 4. zal resulteren in een straf van de 3e categorie.
7. Bij herhaalde overtredingen van lid 1,2,3 of 4 door een gang kan er worden overgegaan op gangstrikes.
8. Bij het fouilleren geef je altijd aan dat je dit doet zodat de andere persoon dit ook weet.
9. Het overtreden van lid 8 zal resulteren in een straf van de 1e categorie.

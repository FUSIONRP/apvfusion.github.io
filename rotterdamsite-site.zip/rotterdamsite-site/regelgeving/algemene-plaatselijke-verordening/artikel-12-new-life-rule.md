# Artikel 12 - New Life Rule

1. Indien uw karakter dood is gegaan wordt er verwacht dat Hij/zij de laatste roleplay vergeten is.
2. Bij een overtreding van de regel in lid 1 wordt de overtreder bestraft met een bestraffing van de 2e categorie.

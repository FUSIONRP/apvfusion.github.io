# Artikel 46 - helikopters/vliegtuigen

1. Het is niet toegestaan om op plekken te landen waar dit als onrealistisch gezien wordt.
2. Het is niet toegestaan om op daken te laden waarvan het gebouw zichtbaar niet sterk genoeg daarvoor is.
3. Het is niet toegestaan om op plekken te landen waar dit als onrealistisch gezien wordt.
4. Het is niet toegestaan om op daken te laden waarvan het gebouw zichtbaar niet sterk genoeg daarvoor is.
5. Bij overtreding van het feit beschreven in lid 1,2,3 of 4 wordt een straf van de 1e categorie uitgedeeld.

De volgende gebieden worden gezien als nofly zones:

- Blokkenpark
- Overheidslocaties (politie bureau, anwb, ziekenhuis, kmar gebouw)

Mocht jij in het bezit zijn van een helikopter, ga er dan verantwoordt mee om. Probeer je helikopter ten alle tijden op de volgende plekken te landen:

- Helipads
- Open weides
- Zichtbaar stabiele gebouwen


# Artikel 34 - Ontsnappen uit het cellencomplex

1. Het is toegestaan om te ontsnappen uit het cellencomplex of vanuit het gevangenentransport, echter dient hier een geldig roleplayscenario aan gekoppeld te worden. Dit is ter beoordeling aan een stafflid.
2. Het is niet toegestaan om te ontsnappen of jezelf uit te laten breken indien er is afgesproken om het roleplayscenario op een later tijdstip voort te zetten, bijvoorbeeld vanwege tijdsgebrek of andere beperkingen.
3. Het is niet toegestaan om een uit-dienst politiemedewerker te ontvoeren om een ontsnapping van een arrestant uit het cellencomplex te faciliteren of te vergemakkelijken. Deze agenten zijn op dat moment immers niet bezig met de uitvoering van de politietaak.
4. Er moeten minimaal 15 agenten (inclusief KMar) online zijn om te mogen ontsnappen uit de gevangenis.
5. Bij overtreding zal er een straf uitgedeeld worden volgens de 3e categorie en zal het roleplayscenario worden teruggedraaid.

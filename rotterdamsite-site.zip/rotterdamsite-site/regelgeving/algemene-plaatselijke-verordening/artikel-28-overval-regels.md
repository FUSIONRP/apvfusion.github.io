# Artikel 28 - Overval Regels

1. Het plegen van een overval met bijvoorbeeld een jerrycan is niet toegestaan, hiervoor mogen enkel items gebruikt worden dat gezien wordt als wapen.
2. Het plaatsen van spijkermatten voor een auto tijdens een overval is niet toegestaan.
3. Het plegen van een overval MET minimaal 1 hostage kan enkel met MINIMAAL 1 vuurwapen.
4. Het plegen van een overval ZONDER hostages kan enkel als er een uitgebreide roleplay aan te pas komt (Het scenario MOET uitgebreid voorgelegd worden via een ticket ter goedkeuring).
6. Wanneer de regel zoals in lid 1 overtreden wordt zal dit bestraft worden met een straf volgens de 4e categorie.
7. Wanneer de regel zoals in lid 2 overtreden wordt zal dit bestraft worden met een straf volgens de 2e categorie.
8. Wanneer de regel zoals in lid 3 overtreden wordt dan zal de politie/kmar ten alle tijden mogen invallen.
9. Wanneer de regel zoals in lid 4 overtreden wordt dan zal de politie/kmar ten alle tijden mogen invallen.

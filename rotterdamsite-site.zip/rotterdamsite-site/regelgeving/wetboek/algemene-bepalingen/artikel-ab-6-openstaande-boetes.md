# Artikel AB 6 - Openstaande boetes

1. Wanneer er openstaande boetes zijn behoudt de politie het recht om een inbeslaggenomen voertuig onder zich te houden of onder zich te nemen.
2. Wanneer er bij een staandehouding of aanhouding blijkt dat betrokkene, of verdachte, openstaande boetes heeft, kan er een taakstraf worden opgelegd van 0.1% van het openstaande bedrag. Bij 10.000 euro, gaat dit dus om 10 taken.
3. Lid 1 en 2 is alleen van toepassing wanneer er 10.000,- euro of meer aan openstaande boetes zijn.

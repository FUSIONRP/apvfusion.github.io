# Artikel AB 9 - Verjaring van het strafbaar feit

1. Het recht tot strafvervolging vervalt indien;
   * het betreft misdrijven waar de totale strafeis tussen de 1 en 50 taken bedroeg, verjaren deze feiten na 14 dagen;
   * het betreft misdrijven waar de totale strafeis tussen de 51+ taken, verjaren deze feiten na 30 dagen;
   * het betreft misdrijven waar de totale strafeis tussen de 0 en 100 maanden bedroeg, verjaren deze feiten na 30 dagen;
   * het betreft misdrijven waar de totale strafeis meer dan 100 maanden bedroeg, verjaren deze feiten na 60 dagen;

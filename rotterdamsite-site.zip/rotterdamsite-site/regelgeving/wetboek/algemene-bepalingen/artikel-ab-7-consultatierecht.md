# Artikel AB 7 - Consultatierecht

1. Elke aangehouden verdachte heeft het recht op kostenloze bijstand van een piket advocaat voorafgaand en tijdens het verhoor.
2. Elke verdachte heeft krachtens artikel 6 van het Europees Verdrag voor de Rechten van de Mens, voorafgaand aan een politieverhoor, toegestaan consultatie te ontvangen van zijn of haar voorkeursadvocaat.
3. Indien de voorkeursadvocaat genoemd in lid 2 niet beschikbaar is, is een vervangend advocaat afdoende om te voldoen aan dit recht.
4. Indien de verdachte de in lid 3 genoemde vervangend advocaat weigert, kan van een advocaat worden afgezien.
5. Een verdachte mag afzien van zijn of haar recht tot consultatie en/of verhoor bijstand van een advocaat.
6. Een verdachte mag zich laten bijstaan door maximaal 1 advocaat, zijnde een voorkeur- of piketadvocaat, met maximaal 1 stagaire.
7. Van de in lid 1, lid 2 en lid 3 benoemde bepaling kan worden afgewijkt indien er niet binnen 15 minuten (realtime) een advocaat beschikbaar is.
8. Als advocaat is alleen toe gestaan hij, of zij, die in de rechtmatige uitoevening is van het beroep advocaat en wie daarnaar gekleed is. Een advocaat is enkel rechtmatig in uitoevening indien hij, of zij:
   * gekleed is in een toga of smoking;
   * geen strafblad heeft;
   * geen openstaande straf/boete heeft;
   * geen voorwerpen bij zich draagt welke niet bij een advocaat in rechtmatige uitvoeren behoren.

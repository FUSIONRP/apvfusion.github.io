# Artikel AB 8 - Algemene aanvulling

1. Onder goederen wordt verstaan alles wat tussen twee personen kan worden uitgewisseld.
   * Hieronder valt, onder andere, alles wat in de inventaris gevonden kan worden, alsmede voertuigen.
2. Onderzoek, tenzij expliciet anders aangegeven, duurt in de regel maximaal 48 uren.
3. Als na deze termijn geen conclusie is getrokken of getrokken kan worden, is de Overheid verplicht tot het retourneren van de onderzochte goederen.
4. Zij, die in dienst van de Overheid, genoodzaakt zijn een actie uit te voeren welke volgens de wet verboden is, kunnen vanwege het noodzakelijk aspect, binnen de contouren van hun functie, niet aangeklaagd worden als zijnde in overtreding van de wet.
5. Bovenstaande ontslaat ambtenaren in dienst van de Overheid niet van alle overige rechtsvervolging.
6. Indien de zaak daarom vraagt, kan de politie kiezen om een verdachte in voorarrest plaatsen. Voorarrest kan voor de duur van maximaal 24 uren.
7. Voorarrest kan tot maximaal 3 keer worden verlengt wanneer daar een goede reden voor is. Nalatigheid van de politie zorgt hierbij voor directe vrijspraak. Nalatigheid van de verdachte is wel een grond tot verlengen.
8. Bij vrijlating / sepot kan geen aanspraak worden gemaakt op een eventuele schade vergoeding, tenzij anders aangegeven.

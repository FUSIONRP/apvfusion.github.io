# Artikel AB 1 - Reikwijdte

1. Het Wetboek van Rotterdam RP, hierna aangeduid als WvARP, is leidend voor alle beschreven gevallen, waarbij als aanvulling het Nederlands Recht van toepassing is.
2. Het Wetboek heeft betrekking op het vaste land, de gemeente, en de stad Rotterdam RP. In gevallen welke niet specifiek benoemt zij onder deze wet is het Nederlandse Recht van toepassing.
3. Het Wetboek is nauw verweven met de Algemene Plaatselijke Verordening Rotterdam RP (APV). De APV dient echter als een indicerend kader voor eventuele bestraffing in-game ('in RP') en is verder bedoeld voor het afhandelen van straffen buiten de RP om.

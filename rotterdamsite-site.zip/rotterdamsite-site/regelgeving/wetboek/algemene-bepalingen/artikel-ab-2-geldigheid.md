# Artikel AB 2 - Geldigheid

1. Bij veranderingen van een wetgeving na het tijdstip waarop het feit begaan is, worden de voor de verdachte meest gunstigste bepalingen toegepast.
2. De in lid 1 benoemde bepaling is alleen geldig wanneer er nog geen uitspraak is in een lopende zaak.
3. Het is voor een staff-lid niet toegestaan om mee te beslissen over een zaak die over hunzelf gaat. Hiermee wordt een eerlijke en rechtvaardige manier van behandelen verzorgt.
4. Er wordt geen onderscheidt gemaakt in minderjarigen en volwassenen. Ongeacht de leeftijd wordt berecht volgens het volwassenen recht.

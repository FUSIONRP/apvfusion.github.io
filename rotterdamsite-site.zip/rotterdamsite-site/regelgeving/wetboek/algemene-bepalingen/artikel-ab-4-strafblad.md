# Artikel AB 4 - Strafblad

1. Straffen die enige vorm van celstraf bevatten leiden tot een strafblad.
2. Een strafblad blijft staan voor de duur van 1 (realtime) maand, tenzij anders is bepaald.
3. Een strafblad van een geweldsmisdrijf blijft staan voor de duur van 2 (realtime) maanden.

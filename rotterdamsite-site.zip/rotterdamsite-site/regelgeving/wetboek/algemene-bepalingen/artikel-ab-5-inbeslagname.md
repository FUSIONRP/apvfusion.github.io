# Artikel AB 5 - Inbeslagname

1. De keuze tot inbeslagname is ter beoordeling van de Politie.
2. Inbeslagname is mogelijke ter; Verbeurtverklaring, onttrekken aan het verkeer, waarheidsvinding en aantonen wederrechtelijk verkregen voordeel.
3. Inbeslagname is mogelijk op goederen.
4. Een goed kan in beslag worden genomen wanneer een strafbaar feit gepleegd is met een goed, of wanneer een goed uit misdrijf is verkregen.
5. Indien de inbeslagname een voertuig betreft dan;
   * Kan deze maximaal drie (3) dagen worden vastgehouden voor onderzoek;
   * Zal deze, nadat bewijsbaar is aangetoond dat het voertuig onderdeel was van een misdrijf, waarbij de eigenaar ook veroordeeld is, uitgekocht kunnen worden voor 20% van de cataloguswaarde;
   * Zal deze kosteloos worden teruggegeven (na eventueel onderzoek) indien de eigenaar geen strafbaar feit ten laste is gelegd, of kan worden gelegd, welke in directe zin gekoppeld is aan de reden van inbeslagname.
   * Uitzonderingsgrond voor teruggave van het voertuig is, indien het een ilegale voertuig betreft. In dit geval zal het voertuig verbeurd worden verklaard.
6. Van het 4e lid kan worden afgeweken indien een voertuig verbeurd word verklaard als aanvullende straf. In dit geval zal overlegd moeten worden met een raadslid van de gemeente Rotterdam.

# Artikel AB 3 - Strafbepaling

1. Straffen zijn vastgesteld en opgenomen per artikel. Hieronder vallen:
   * Waarschuwingen;
   * Taakstraffen;
   * Celstraffen;
   * Rijontzeggingen;
   * Inbeslagnames of invorderingen;
   * Boetes.
2. Een opgelegde straf kan een combinatie zijn van meerdere strafvormen, alsin benoemt in lid 1.
3. Een opgelegde straf kan niet hoger zijn dan de vastgestelde waarden.
4. Een straf kan verhoogd worden door te stapelen van overtredingen en/of misdrijven.
5. Indien er sprake is van meerdere slachtoffers binnen het zelfde misidrijf, dan wordt er voor elk extra slachtoffer 1/3e van de oorspronkelijke straf bij de uiteindelijke straf toegevoegd.
6. Een straf kan verlaagd worden bij verzachtende omstandigheden.
7. Een straf kan geheel of gedeeltelijk kwijtgescholden en/of uitgesloten worden op basis van uitsluitingsgronden of bewijsbaar foutieve uitschrijving van de straf.
8. Bij een mislukt strafbaarfeit (poging) wordt maximaal 2/3e van de oorspronkelijke straf bij de uiteindelijke straf toegevoegd.
9. Bij het opleggen van een celstraf kan een eventuele taakstraf omgezet worden in een celstraf, of een celstraf in een taakstraf.
10. Bij de in lid 9 bedoelde omzetting kan voor elke - 2 taken 1 maand cel worden berekend. - 1 maand cel 2 taken worden berekend.
11. De politie kan overeen komen met de verdachte om een boete om te zetten in een taakstraf.
12. er mag een maximum straff gegeven worden van maximaal 300 maanden

* als er meer dan 300 maanden gegeven wordt dan wordt er een berekening gemaakt alle maanden boven de 300 maanden wordt berekend op de volgende wijzen.
* 1 maand is 500 boete
* een rechter kan straf geven boven de 300 maanden en met een maximum van 500 maanden

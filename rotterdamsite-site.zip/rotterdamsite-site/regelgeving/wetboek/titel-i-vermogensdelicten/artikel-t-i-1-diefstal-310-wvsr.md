# Artikel T-I 1 - Diefstal (310 WvSR)

1. Schuldig is een persoon die een goed, of voertuig, wegneemt zonder daarvoor toestemming of enig recht toe te hebben.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     |            | 8 uur       | € 3.700,-  |
| **Tweede Veroordeling**     |            | 20 uur      | € 7.400,-  |
| **Meerdere Veroordelingen** |            | 30 uur      | € 14.800,- |

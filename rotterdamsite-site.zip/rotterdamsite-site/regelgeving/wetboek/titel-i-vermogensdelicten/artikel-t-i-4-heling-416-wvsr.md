# Artikel T-I 4 - Heling (416 WvSR)

1. Schuldig is een persoon die een goed, afkomstig uit een misdrijf, verwerft of hierop aanspraak maakt.
2. Schuldig is een persoon die voordeel trekt uit opbrengst van een door misdrijf verkregen goed.
3. Niet schuldig is een persoon die redelijkerwijs geen weet heeft, of kan hebben, van de afkomst uit een misdrijf van het goed.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            | 15 uur      | € 2.000,- |
| **Tweede Veroordeling**     |            | 25 uur      | € 5.000,- |
| **Meerdere Veroordelingen** |            | 55 uur      | € 6.500,- |

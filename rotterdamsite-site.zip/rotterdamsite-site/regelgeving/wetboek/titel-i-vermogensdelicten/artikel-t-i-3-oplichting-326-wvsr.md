# Artikel T-I 3 - Oplichting (326 WvSR)

1. Schuldig is een persoon die door het aannemen van een valse naam, of een valse hoedanigheid, hetzij door listige kunstgrepen, hetzij door een samenweefsel van verdichtsels, iemand beweegt tot de afgifte van enig goed, tot het verlenen van een dienst, tot het ter beschikking stellen van gegevens, tot het aangaan van een schuld of tot het teniet doen van een inschuld, wordt, als schuldig aan oplichting, gestraft.
2. Schuldig is een persoon wie een dienst of goed afneemt zonder de daarvoor afgesproken afspraken na te komen.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 10 maanden |             | € 3.700,-  |
| **Tweede Veroordeling**     | 20 maanden |             | € 7.400,-  |
| **Meerdere Veroordelingen** | 40 maanden |             | € 14.800,- |

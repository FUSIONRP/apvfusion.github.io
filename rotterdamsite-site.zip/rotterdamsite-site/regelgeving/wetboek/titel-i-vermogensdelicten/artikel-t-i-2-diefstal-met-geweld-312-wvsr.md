# Artikel T-I 2 - Diefstal met geweld (312 WvSR)

1. Schuldig is een persoon die een goed wegneemt zonder daarvoor toestemming of enig recht toe te hebben, daarbij gebruik makende van geweld in enige vorm.
2. Genoemd geweld is gebruikt bij de voorbereiding, diefstal of overval, of vlucht.
3. Wanneer het slachtoffer medeplichtig is wordt de straf met 1/3 verlaagd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 10 maanden |             | € 9.300,-  |
| **Tweede Veroordeling**     | 25 maanden |             | € 18.500,- |
| **Meerdere Veroordelingen** | 30 maanden |             | € 26.800,- |

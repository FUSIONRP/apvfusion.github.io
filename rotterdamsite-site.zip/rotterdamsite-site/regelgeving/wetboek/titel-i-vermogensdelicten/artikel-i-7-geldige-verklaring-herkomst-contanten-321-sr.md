# Artikel I-7 Geldige verklaring herkomst contanten (321 SR)

1. Wanneer er tijdens aanhouding van een persoon door de Politie een geldbedrag, hoger dan €10,000 aan contanten, aangetroffen wordt bij die persoon, zal er om geldige verklaring van herkomst gevraagd worden.
2. Wanneer deze verklaring niet bewijsbaar of redelijkerwijs aannemelijk is, is het de Politie toegestaan dit bedrag in beslag te nemen voor onderzoek.
3. Wanneer onderzoek geen criminele herkomst kan aantonen, dan is Politie gemaand tot restitutie van het inbeslaggenomen geld bedrag. Hierbij kan de verdachte geen aanspraak maken op wettelijke rente of andere verhoging.
4. Wanneer onderzoek, volgend op de inbeslagname zoals bedoeld in lid 2, criminele herkomst aantoont, dan zal de inbeslaggenomen som vernietigd worden.

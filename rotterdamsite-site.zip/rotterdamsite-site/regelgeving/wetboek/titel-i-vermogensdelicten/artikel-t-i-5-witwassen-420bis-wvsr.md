# Artikel T-I 5 - Witwassen (420bis WvSR)

1. Schuldig is een persoon die geld of goederen, verkregen uit misdrijf, vermengt of poogt te vermengen met het reguliere circuit van geld en goederen.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 25 maanden |             | € 14.800,- |
| **Tweede Veroordeling**     | 50 maanden |             | € 23.300,- |
| **Meerdere Veroordelingen** | 90 maanden |             | € 27.000,- |

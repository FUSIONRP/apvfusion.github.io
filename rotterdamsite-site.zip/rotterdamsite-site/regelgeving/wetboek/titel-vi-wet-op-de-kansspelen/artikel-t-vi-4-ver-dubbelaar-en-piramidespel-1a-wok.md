# Artikel T-VI 4 - Ver dubbelaar en piramidespel (1a Wok)

1. Schuldig is een persoon die zonder geldige vergunning een gelegenheid biedt om geld of goederen te verdubbelen door het afgeven of overmaken van een voorgesteld bedrag of goed.
2. Schuldig is een persoon die zonder geldige vergunning geld of goederen eist, teneinde daaruit een voordeel uit te beloven dat geheel of ten dele afhankelijk is van de afgifte van geld of goederen door latere deelnemers.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     |            | 5 uur       | € 2.500,-  |
| **Tweede Veroordeling**     |            | 10 uur      | € 5.000,-  |
| **Meerdere Veroordelingen** |            | 20 uur      | € 10.000,- |

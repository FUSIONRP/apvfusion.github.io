# Artikel T-VI 1 - Algemeen verbod (1 WoK)

1. Schuldig is een persoon die zonder geldige vergunning een gelegenheid biedt om mee te dingen naar prijzen of geld, in de vorm van een kansspel.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            |             | € 1.000,- |
| **Tweede Veroordeling**     |            |             | € 2.500,- |
| **Meerdere Veroordelingen** |            |             | € 7.500,- |

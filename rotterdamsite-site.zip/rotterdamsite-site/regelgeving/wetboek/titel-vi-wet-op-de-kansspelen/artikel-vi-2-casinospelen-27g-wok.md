# Artikel VI-2 Casinospelen (27g Wok)

1. Schuldig is een persoon die zonder geldige vergunning casinospelen op basis van kansbepaling publiekelijk of bedrijfsmatig aanbiedt.
2. De Overheid behoudt het recht om op één of enkele plekken casinospelen geautomatiseerd aan te bieden.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            | 5 uur       | € 1.000,- |
| **Tweede Veroordeling**     |            | 10 uur      | € 2.500,- |
| **Meerdere Veroordelingen** |            | 20 uur      | € 5.000,- |


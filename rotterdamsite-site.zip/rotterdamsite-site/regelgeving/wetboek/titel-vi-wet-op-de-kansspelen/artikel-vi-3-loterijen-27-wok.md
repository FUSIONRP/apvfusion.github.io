# Artikel VI-3 Loterijen (27 Wok)

1. Schuldig is een persoon die zonder geldige vergunning een gelegenheid biedt om mededingers een aantal symbolen en/of cijfers te doen voorspellen, die door loting of trekking worden verkregen uit een van tevoren opgegeven aantal symbolen en/of cijfers.
2. Schuldig is een persoon die zonder geldige vergunning een loterij houdt waarbij een winnend lotnummer door trekking wordt gekozen.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            |             | € 2.500,- |
| **Tweede Veroordeling**     |            | 10 uur      | € 5.000,- |
| **Meerdere Veroordelingen** |            | 20 uur      | € 7.500,- |

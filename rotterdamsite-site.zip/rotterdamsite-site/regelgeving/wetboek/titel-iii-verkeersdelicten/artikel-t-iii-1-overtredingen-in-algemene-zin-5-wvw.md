# Artikel T-III 1 - Overtredingen in algemene zin (5 WvW)

1. Voor verkeersovertredingen in algemene zin, welke niet gespecificeerd zijn als zwaardere delicten, geldt een geldboete van €500,- per geval.
2. Er kan door de opsporing ambtenaar worden gekozen om een waarschuwing te geven in plaats van een boete.

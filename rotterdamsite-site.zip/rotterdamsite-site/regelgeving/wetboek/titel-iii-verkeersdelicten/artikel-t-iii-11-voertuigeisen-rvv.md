# Artikel T-III 11 - Voertuigeisen  (RVV)

1. Schuldig is een persoon van wie zijn of haar voertuig niet voldoet aan de volgende eisen:
   * Het is voorzien van 1 of meer nummerplaten, tenzij het gaat om een fiets.
   * Het moet voorzien zijn van ramen waarbij het gezicht van de bestuurder en passagier(s) goed zichtbaar te zien zijn erdoor heen.
   * Het voertuig mag niet voorzien zijn van NEON.
   * Het voertuig moet voorzien zijn van een VIN-nummer. (Frame-nummer)
   * De carrosserie dient in ordere te zijn en mag geen uitstekende delen bevatten.
   * Het voertuig is voorzien van een claxon, deze mag maximaal 1 toon gebruiken.
2. Indien een VIN-nummer niet meer in originele staat is, dient het voertuig in beslag te worden genomen en kan de bestuurder en/of te naam gestelde worden aangemerkt voor het strafbare feit heling.
3. Indien het voertuig niet voldoet aan de in lid 1 benoemde eisen, kan het voertuig een WOK status krijgen.
4. Indien een voertuig voorzien is van een WOK status, mag deze niet meer rijden over de openbare weg. Het voertuig dient ten alle tijden te worden voorbewogen door een sleepwagen.
5. Indien er wordt gereden met een voertuig voorzien van een WOK status, kan deze in beslag worden genomen en kan er een boete worden opgelegd van € 2500,-. Eventuele sleepkosten kunnen worden doorberekend aan de eigenaar van het voertuig.
6. Niet strafbaar is hij die een rechtmatig verkregen vergunning kan tonen welke afgegeven en ondertekend is door de burgemeester.

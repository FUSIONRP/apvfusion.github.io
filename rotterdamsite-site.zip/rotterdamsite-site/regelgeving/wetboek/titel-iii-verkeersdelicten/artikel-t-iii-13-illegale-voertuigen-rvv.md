# Artikel T-III 13 - Illegale voertuigen  (RVV)

1. Schuldig is een persoon wie zijn of haar voertuig, welke staat aangegeven als illegaal voertuig, zich bevind op een plek of plaats anders dan eigen- en/of privéterrein.
2. Indien een persoon wordt aangetroffen op zijn of haar voertuig zoals bedoeld in lid 1, wordt het voertuig direct in beslag genomen en vernietigd.
3. Indien de persoon zoals in lid 2 bedoelt niet de eigenaar van het voertuig betreft, wordt eveneens het voertuig direct in beslag genomen en vernietigd.
4. De eigenaar van het voertuig is verantwoordelijk, ook al wordt het voertuig zonder bestuurder of met een andere bestuurder aangetroffen.

# Artikel T-III 9 - Fout parkeren (25 RVV)

1. Schuldig is een persoon die zijn of haar voertuig parkeert op een wijze die niet sluit met de aangegeven parkeersituatie, zoals:
   * Dubbel parkeren;
   * Parkeren langs een rode trottoirrand;
   * Parkeren op een rijbaan;
   * Parkeren op de stoep;
   * Stilstaan op de stoep.
2. Indien er geen bestuurder bekend is, is de te naam gestelde van het voertuig verantwoordelijk.
3. De vastgestelde boete bedraagt € 1250,-
4. Indien het voertuig hinderlijk staat, kan het voertuig worden afgesleept en dient de te naam gestelde deze kosten te voldoen.


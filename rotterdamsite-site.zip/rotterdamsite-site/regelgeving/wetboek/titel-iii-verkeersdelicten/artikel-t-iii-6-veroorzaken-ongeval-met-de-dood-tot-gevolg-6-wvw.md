# Artikel T-III 6 - Veroorzaken ongeval, met de dood tot gevolg (6 WvW)

1. Schuldig is een persoon wie een ongeval veroorzaakt, met de dood tot gevolg, door niet de verkeersregels in acht te nemen.
2. Het rijbewijs wordt ten alle tijden ingevorderd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    | _rijontzegging_ |
| --------------------------- | ---------- | ----------- | ---------- | --------------- |
| **Eerste Veroordeling**     | 10         |             | € 7500,-   | 24 uur          |
| **Tweede Veroordeling**     | 15 maanden |             | € 15.000,- | 24 uur          |
| **Meerdere Veroordelingen** | 20 maanden |             | € 20.000,- | 24 uur          |

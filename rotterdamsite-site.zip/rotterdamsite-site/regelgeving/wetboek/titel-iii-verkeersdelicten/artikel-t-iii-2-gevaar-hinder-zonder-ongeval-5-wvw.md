# Artikel T-III 2 - Gevaar / hinder zonder ongeval (5 WvW)

1. Schuldig is een persoon die zich zodanig gedraagt in het verkeer dat er sprake kan zijn van gevaar en/of hinder op de openbare weg.
2. Wanneer de gedragingen lijden tot de mogelijkheid van aanzienlijk gevaar en/of hinder, kan er worden overgegaan tot invordering van het rijbewijs.
3. Dit artikel betreft een verkeersmisdrijf.

|                             | _Celstraf_ | _Taakstraf_ | _boete_  | _rijontzegging_ |
| --------------------------- | ---------- | ----------- | -------- | --------------- |
| **Eerste Veroordeling**     |            |             | € 1875,- | 0-24 uur        |
| **Tweede Veroordeling**     |            | 10 uur      | € 3750,- | 0-24 uur        |
| **Meerdere Veroordelingen** |            | 20 uur      | € 7500,- | 0-24 uur        |

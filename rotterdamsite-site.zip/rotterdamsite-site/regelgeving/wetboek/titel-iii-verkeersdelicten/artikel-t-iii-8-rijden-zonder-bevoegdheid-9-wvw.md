# Artikel T-III 8 - Rijden zonder bevoegdheid  (9 WvW)

1. Schuldig is een persoon wie weet of redelijkerwijs behoort te weten dat hem of haar de rijbevoegdheid is ontzegd en desondanks deelneemt aan het verkeer in een voertuig waarvoor een rijbewijs vereist is.
2. Wanneer de bevoegdheid is ontzegd middels een invordering van het rijbewijs, dan geldt dit voor alle categoriën van dat rijbewijs.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   | _rijontzegging_ |
| --------------------------- | ---------- | ----------- | --------- | --------------- |
| **Eerste Veroordeling**     |            | 8 uur       | €4350,-   | 24 uur          |
| **Tweede Veroordeling**     |            | 15 uur      | €8700,-   | 24 uur          |
| **Meerdere Veroordelingen** |            | 20 uur      | €17.400,- | 24 uur          |

# Artikel T-III 7 - Verlaten plaats van verkeersongeval  (7 WvW)

1. Schuldig is een persoon wie een plaats van een verkeersongeval verlaat, indien deze betrokken was bij het ongeval.
2. Niet ter zake doet het of hij of zij schuldig was aan het veroorzaken van het ongeval.
3. Indien een derde wordt achtergelaten in hulpeloze toestand wordt de straf verhoogd met 1/3.
4. Wanneer de persoon zich nadien, tijdig, alsnog meldt bij de politie zal worden afgezien van strafvervolging.
5. Wanneer de persoon wordt gevonden door de politie vervalt lid 4.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    | _rijontzegging_ |
| --------------------------- | ---------- | ----------- | ---------- | --------------- |
| **Eerste Veroordeling**     |            | 10 uur      | € 4500,-   |                 |
| **Tweede Veroordeling**     |            | 20 uur      | € 9000,-   |                 |
| **Meerdere Veroordelingen** | 25 maanden |             | € 18.000,- |                 |

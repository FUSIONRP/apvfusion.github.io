# Artikel T-III 12 - Overige verkeersboetes  (WvW / RVV)

1. Momenteel geldt het feitenboekje van het OM waar deze wet niet toereikend is.
2. Voor feiten benoemd in het feitenboekje kan de boete 'Algemene verkeersovertreding' worden uitgeschreven.

# Artikel T-III 5 - Veroorzaken ongeval, met zwaar lichamelijk letsel tot gevolg (6 WvW)

1. Schuldig is een persoon wie een ongeval veroorzaakt, waarbij zwaar lichamelijk letsel aan een derde tot gevolg is, door niet de verkeersregels in acht te nemen.
2. Onder zwaar lichamelijk letsel wordt verstaan al het letsel waarbij een ziekenhuisopname noodzakelijk is.
3. Het rijbewijs wordt ten alle tijden ingevorderd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    | _rijontzegging_ |
| --------------------------- | ---------- | ----------- | ---------- | --------------- |
| **Eerste Veroordeling**     |            | 15 uur      | € 3.000,-  | 24 uur          |
| **Tweede Veroordeling**     |            | 20 uur      | € 6.000,-  | 24 uur          |
| **Meerdere Veroordelingen** |            | 25 uur      | € 12.000,- | 24 uur          |

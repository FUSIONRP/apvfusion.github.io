# Artikel T-III 4 - Veroorzaken ongeval, met al dan niet licht lichamelijk letsel tot gevolg (6 WvW)

1. Schuldig is een persoon wie een ongeval veroorzaakt, waarbij licht lichamelijk letsel aan een derde tot gevolg is, door niet de verkeersregels in acht te nemen.
2. Onder licht lichamelijk letsel wordt verstaan al het letsel welke zonder ziekenhuisopname behandeld kan worden.
3. Op basis van inschatting van de feiten en omstandigheden kan eveneens overgegaan worden tot invordering van het rijbewijs en/of inbeslagname van het voertuig.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   | _rijontzegging_ |
| --------------------------- | ---------- | ----------- | --------- | --------------- |
| **Eerste Veroordeling**     |            | 15 uur      | € 950,-   | 24 uur          |
| **Tweede Veroordeling**     |            | 25 uur      | € 1.850,- | 24 uur          |
| **Meerdere Veroordelingen** |            | 35 uur      | € 3.700,- | 24 uur          |

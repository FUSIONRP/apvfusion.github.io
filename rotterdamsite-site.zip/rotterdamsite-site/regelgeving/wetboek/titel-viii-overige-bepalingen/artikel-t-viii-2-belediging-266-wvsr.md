# Artikel T-VIII 2 - Belediging (266 WvSR)

1. Schuldig is een persoon die opzettelijk een ander belegdigt waarbij de ander zich beldigd voelt.
2. De belediging dient in het openbaar te gebeuren.
3. Wanneer de belediging opzettelijk is geuit richting een ambtenaar in functie wordt de straf met 1/3 verhoogd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            |             | € 1.200,- |
| **Tweede Veroordeling**     |            |             | € 2.000,- |
| **Meerdere Veroordelingen** |            |             | € 2.500,- |

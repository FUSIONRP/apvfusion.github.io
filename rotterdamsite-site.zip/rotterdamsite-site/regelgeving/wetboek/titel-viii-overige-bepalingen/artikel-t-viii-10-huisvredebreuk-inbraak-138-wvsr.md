# Artikel T-VIII 10 - Huisvredebreuk / Inbraak (138 WvSR)

1. Schuldig is een persoon die een woning of besloten lokaal of erf bij een ander in gebruik, wederrechtelijk binnendringt of, wederrechtelijk aldaar vertoevende, zich niet op de vordering van of vanwege de rechthebbende aanstonds verwijdert.
2. Schuldig is een persoon die zich de toegang heeft verschaft door middel van braak of inklimming, van lockpicks, van een valse order of vals kostuum, of die, zonder voorkennis van de rechthebbende en anders dan ten gevolge van vergissing binnengekomen, aldaar wordt aangetroffen in de voor de nachtrust bestemde tijd, wordt geacht te zijn binnengedrongen.
3. In geval van het tweede lid wordt de staf met 1/3 verhoogd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            | 20 uur      | € 2.000,- |
| **Tweede Veroordeling**     |            | 40 uur      | € 4.000,- |
| **Meerdere Veroordelingen** |            | 50 uur      | € 6.000,- |

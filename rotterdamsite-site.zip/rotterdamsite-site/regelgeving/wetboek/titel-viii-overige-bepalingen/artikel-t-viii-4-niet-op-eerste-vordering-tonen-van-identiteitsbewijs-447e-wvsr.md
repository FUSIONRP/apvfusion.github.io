# Artikel T-VIII 4 - Niet op eerste vordering tonen van identiteitsbewijs (447e  WvSR)

1. Schuldig is een persoon die geen gehoor geeft aan een vordering tot inzage van het identiteitsbewijs door een ambtenaar in functie, wanneer dit in het kader van de wet door de ambtenaar als noodzakelijk wordt geacht.
2. Hij die wordt veroordeeld voor lid 1 krijgt een boete van €9000,- per geval.
3. Indien de ambtenaar in functie een boete als in lid 2 bedoeld wilt opleggen, en dit niet kan doordat de identiteit uitblijft, kan worden aangehouden voor artikel T-VIII 1.

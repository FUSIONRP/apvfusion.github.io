# Artikel T-VIII 9 - Lokaalvredebreuk (139 WvSR)

1. Schuldig is een persoon die in een voor de openbare dienst bestemd lokaal, openbare ruimte of besloten erf dat bestemd is voor de openbare dienst, wederrechtelijk binnendringt, of, wederrechtelijk aldaar vertoevende, zich niet op de vordering van de bevoegde ambtenaar aanstonds verwijdert.
2. Schuldig is een persoon die zich de toegang heeft verschaft door middel van braak of inklimming, van valse sleutels, van een valse order of een vals kostuum, of die zonder voorkennis van de bevoegde ambtenaar en anders dan ten gevolge van vergissing binnengekomen, aldaar wordt aangetroffen in de voor de nachtrust bestemde tijd, wordt geacht te zijn binnengedrongen.
3. In geval van het tweede lid wordt de staf met 1/3 verhoogd.

|                         | Celstraf | Taakstraf | boete     |
| ----------------------- | -------- | --------- | --------- |
| Eerste Veroordeling     |          | 35 uur    | € 1.500,- |
| Tweede Veroordeling     |          | 40 uur    | € 2.000,- |
| Meerdere Veroordelingen |          | 50 uur    | € 3.000,- |

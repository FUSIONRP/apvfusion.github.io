# Artikel T-VIII 3 - Opgeven valse gegevens (435  WvSR)

1. Schuldig is een persoon die bij vordering van een ambtenaar in functie valse gegevens opgeeft, op straffe van een boete van €4500,- per geval.

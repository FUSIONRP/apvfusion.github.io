# Artikel T-VIII 1 - Niet voldoen aan een bevel of vordering (184 WvSR)

1. Schuldig is een persoon die opzettelijk niet voldoet aan een bevel of vordering dat krachtens wettelijk voorschrift wordt gegeven door een ambtenaar in functie.
2. Schuldig is een persoon die opzettelijk een ambtenaar in functie belemmert in de uitvoering daarvan.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            | 15 uur      | € 320,-   |
| **Tweede Veroordeling**     |            | 30 uur      | € 500,-   |
| **Meerdere Veroordelingen** |            | 40 uur      | € 1.000,- |

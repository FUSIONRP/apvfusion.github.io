# Artikel T-VIII 7 - Deelname aan een criminele organisatie

1. Schuldig is een persoon die deelneemt aan, steun verleent aan, of gelieerd is aan een organisatie die tot doel heeft het plegen van misdrijven.
2. Ten aanzien van de oprichters, leiders of bestuurders worden de gevangenisstraffen met 1/3 verhoogd.
3. Onder deelneming als omschreven in het eerste lid wordt mede begrepen het verlenen van geldelijke of andere stoffelijke steun aan alsmede het werven van gelden of personen ten behoeve van de daar omschreven organisatie.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            |             | € 3.000,- |
| **Tweede Veroordeling**     |            | 20 uur      | € 6.000,- |
| **Meerdere Veroordelingen** | 20 maanden |             | € 9.000,- |

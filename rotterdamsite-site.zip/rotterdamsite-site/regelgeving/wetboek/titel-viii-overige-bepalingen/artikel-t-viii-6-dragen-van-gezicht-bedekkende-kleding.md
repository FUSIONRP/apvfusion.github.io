# Artikel T-VIII 6 - Dragen van gezicht bedekkende kleding

1. Schuldig is een persoon die kleding draagt, die het gezicht geheel bedekt of zodanig bedekt dat alleen de ogen onbedekt zijn, dan wel onherkenbaar maakt.
2. Het eerste lid is niet van toepassing, voor zover kleding als bedoeld in lid 1:
   * wordt gedragen door cliënten, patiënten of hun bezoekers in residentiële delen van zorginstellingen, of
   * noodzakelijk is ter bescherming van het lichaam in verband met de gezondheid of de veiligheid, of
   * noodzakelijk is in verband met eisen die aan de uitoefening van een beroep of sport worden gesteld, of
   * passend is in verband met het deelnemen aan een feestelijke of een culturele activiteit.
3. Hij die wordt veroordeeld voor lid 1 krijgt een boete van €1000,- per geval.

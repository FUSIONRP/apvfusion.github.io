# Artikel T-VIII 11 - Betreden van verboden terrein

1. Schuldig is een persoon die zonder daartoe gerechtigd is, over militair domein en/of grond waarvan de toegang op een voor hem blijkbare wijze door den rechthebbende is verboden, loopt, rijdt of vee laat lopen.
2. Niet schuldig aan lid 1 kan zijn hij die werkt bij de overheid.

| Bij wet geclassificeerde militaire domeinen |
| ------------------------------------------- |
| Luchtmachtbasis                             |
| Vliegdekschip                               |
| KMar Brigade                                |
|                                             |

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 40 maanden |             | € 10.000,- |
| **Tweede Veroordeling**     | 60 maanden |             | € 20.000,- |
| **Meerdere Veroordelingen** | 90 maanden |             | € 40.000,- |

# Artikel T-VIII 5 - Openbare dronkenschap (453 WvSR)

1. Schuldig is een persoon die zich begeeft in de openbare ruimte terwijl hij of zij in kennelijke staat van dronkenschap verkeert.
2. Hij die wordt veroordeeld voor lid 1 krijgt een boete van €650,- per geval.

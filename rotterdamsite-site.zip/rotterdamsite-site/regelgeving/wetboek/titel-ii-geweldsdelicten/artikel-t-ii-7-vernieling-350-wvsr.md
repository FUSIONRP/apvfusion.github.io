# Artikel T-II 7 - Vernieling (350 WvSR)

1. Schuldig is een persoon die opzettelijk en wederrechtelijk een goed dat geheel of ten dele aan een ander toebehoort, vernielt, beschadigt, onbruikbaar maakt of wegmaakt.
2. Indien het goed aangemerkt kan worden als eigendom van de overheid wordt de straf met 1/3 verhoogd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_  |
| --------------------------- | ---------- | ----------- | -------- |
| **Eerste Veroordeling**     |            | 8 uur       | € 4000,- |
| **Tweede Veroordeling**     |            | 15 uur      | € 5000,- |
| **Meerdere Veroordelingen** |            | 25 uur      | € 7000,- |

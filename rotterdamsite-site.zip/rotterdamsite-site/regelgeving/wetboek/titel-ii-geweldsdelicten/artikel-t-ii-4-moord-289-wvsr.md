# Artikel T-II 4 - Moord (289 WvSR)

1. Schuldig is een persoon die opzettelijk en met voorbedachte rade iemand van het leven berooft.
2. Wanneer het slachtoffer een ambtenaar in functie betreft wordt de straf met 1/3 verhoogd.
3. Wanneer het slachtoffer medeplichtig is wordt de straf met 1/3 verlaagd.

|                             | _Celstraf_  | _Taakstraf_ | _boete_    |
| --------------------------- | ----------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 85 maanden  |             | € 16.700,- |
| **Tweede Veroordeling**     | 90 maanden  |             | € 23.400,- |
| **Meerdere Veroordelingen** | 110 maanden |             | € 30.000,- |

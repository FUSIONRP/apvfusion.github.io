# Artikel T-II 8 - Wederspannigheid / verzet (180 WvSR)

1. Schuldig is een persoon die geweld pleegt of zich gewelddadig verzet tegen een ambtenaar in dienst.

|                             | _Celstraf_ | _Taakstraf_ | _boete_  |
| --------------------------- | ---------- | ----------- | -------- |
| **Eerste Veroordeling**     |            | 20 uur      | € 3000,- |
| **Tweede Veroordeling**     |            | 25 uur      | € 4000,- |
| **Meerdere Veroordelingen** |            | 30 uur      | € 6000,- |

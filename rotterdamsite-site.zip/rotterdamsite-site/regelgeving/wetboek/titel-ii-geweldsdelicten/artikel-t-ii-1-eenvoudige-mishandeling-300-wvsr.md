# Artikel T-II 1 - Eenvoudige Mishandeling (300 WvSR)

1. Schuldig is een persoon die opzettelijk en wederrechtelijk een ander pijn en of letsel toebrengt.
2. Met mishandeling wordt gelijkgesteld het opzettelijk benadelen van de gezondheid.
3. Een poging tot eenvoudige mishandeling is niet vervolgbaar.
4. Wanneer het slachtoffer een ambtenaar in functie betreft wordt de straf met 1/3 verhoogd.
5. Wanneer het slachtoffer medeplichtig is wordt de straf met 1/3 verlaagd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            | 20 maanden  | € 4.300,- |
| **Tweede Veroordeling**     |            | 35 maanden  | € 6.500,- |
| **Meerdere Veroordelingen** |            | 65 maanden  | € 9.500,- |

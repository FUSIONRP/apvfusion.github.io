# Artikel T-II 2 - Zware Mishandeling (302 WvSR)

1. Schuldig is een persoon die opzettelijk en wederrechtelijk een ander pijn en of letsel toebrengt met zwaar lichamelijk letsel tot gevolg.
2. Onder de definitie van zware mishandeling valt letsel waarbij verzorging door ambulance personeel noodzakelijk is.
3. Wanneer het slachtoffer een ambtenaar in functie betreft wordt de straf met 1/3 verhoogd.
4. Wanneer het slachtoffer medeplichtig is wordt de straf met 1/3 verlaagd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 10 maanden |             | € 9.300,-  |
| **Tweede Veroordeling**     | 15 maanden |             | € 11.500,- |
| **Meerdere Veroordelingen** | 20 maanden |             | € 14.000,- |

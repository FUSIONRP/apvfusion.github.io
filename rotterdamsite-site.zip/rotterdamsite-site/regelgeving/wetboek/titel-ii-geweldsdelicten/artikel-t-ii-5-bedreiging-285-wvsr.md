# Artikel T-II 5 - Bedreiging (285 WvSR)

1. Schuldig is een persoon die dreiging uit met gewelddadige inhoud of misdadig karakter, jegens personen of goederen.
2. Wanneer het slachtoffer een ambtenaar in functie betreft wordt de straf met 1/3 verhoogd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     |            | 10 maanden  | € 2.400,- |
| **Tweede Veroordeling**     |            | 15 maanden  | € 3.800,- |
| **Meerdere Veroordelingen** |            | 25 maanden  | € 4.700,- |

# Artikel T-II 3 - Doodslag (287 WvSR)

1. Schuldig is een persoon die opzettelijk een ander van het leven berooft.
2. Wanneer het slachtoffer een ambtenaar in functie betreft wordt de straf met 1/3 verhoogd.
3. Wanneer het slachtoffer medeplichtig is wordt de straf met 1/3 verlaagd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 30 maanden |             | € 13.000,- |
| **Tweede Veroordeling**     | 50 maanden |             | € 18.000,- |
| **Meerdere Veroordelingen** | 80 maanden |             | € 22.000,- |

# Artikel T-II 6 - Gijzeling (282a WvSR)

1. Schuldig is een persoon die overgaat tot wederrechtelijke beroving van de vrijheid van een derde.
2. Wanneer het slachtoffer een ambtenaar in functie betreft wordt de straf met 1/3 verhoogd.
3. Wanneer het slachtoffer medeplichtig is wordt de straf met 1/3 verlaagd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 45 maanden |             | € 9.700,-  |
| **Tweede Veroordeling**     | 55 maanden |             | € 13.400,- |
| **Meerdere Veroordelingen** | 70 maanden |             | € 19.700,- |

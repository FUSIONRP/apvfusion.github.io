# Artikel T-VII 2 - Vormfouten (39-43 WvSR)

1. De hoogte van de straf dient in verhouding tot de ernst van het verzuim te worden verlaagd, indien het door het verzuim veroorzaakte nadeel langs deze weg kan worden gecompenseerd.
2. Met onherstelbaar vormverzuim wordt onder andere bedoeld:
   * een vooringenomen, sturende, druk uitoefenende manier van verhoren;
   * wanneer ontlastende informatie wordt verzwegen, en/of bewijsmateriaal wordt vernietigd;
   * het tappen van een met geheimhoudingsplicht bezwaarde professional, zoals arts, notaris, geestelijke, apotheker, advocaat;
   * het voeren van een meinedig proces-verbaal zijnde tegenstrijdigheid met andere processen-verbaal, camerabeelden, geluidsopnamen;

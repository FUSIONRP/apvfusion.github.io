# Artikel T-VII 1 - Algemene Uitsluitingen (39-43 WvSR)

1. Niet schuldig is een persoon die:
   * door aantoonbaar overmacht is gedwongen een strafbaar feit te begaan;
   * vanwege een noodzakelijke verdediging van eigen of andermans lijf, eerbaarheid of goed tegen ogenblikkelijke, wederrechtelijke aanranding een strafbaar feit begaat;
   * de grenzen van bovenstaande noodweer overtreedt gevolgens een hevige gemoedsbeweging, veroorzaakt door de aanranding;
   * een strafbaar feit begaat ter uitvoering van een wettelijk voorschrift;
   * een strafbaar feit begaat ter uitvoering van een ambtelijk bevel, gegeven door het daartoe bevoegde gezag;
   * een onbevoegd gegeven ambtelijk bevel heft de strafbaarheid niet op, tenzij het door de ondergeschikte te goeder trouw als bevoegd gegeven werd beschouwd en de nakoming daarvan binnen de kring van zijn ondergeschiktheid was gelegen.

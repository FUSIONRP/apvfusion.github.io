# Artikel T-V 6 - Voor handen hebben van munitie

1. Strafbaar is een persoon die munitie bij zich draagd en/of voorhanden heeft.
2. Ter veroordeling van dit feit hoeft de verdachte niet te beschikken over een vuurwapen. Enkel losse munitie is voldoende.
3. Onder munitie wordt verstaan; \* Een patroon houder \* Elk patroon dat door een (automatisch)vuurwapen kan worden afgeschoten.
4. Indien de politie ten tijde van het overdragen de wapenhandel stopt, wordt dit gezien als voltooid feit.
5. Indien de verdachte meer dan 20 patronen bij zich draagt, zal de straf met 1/3e worden verhoogd.

| _**`Categorie 1 Munitie`**_ | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     | 15 maanden |             | € 3.400,- |
| **Tweede Veroordeling**     | 21 maanden |             | € 4.750,- |
| **Meerdere Veroordelingen** | 28 maanden |             | € 5.100,- |

| _**`Categorie  Munitie`**_  | _Celstraf_ | _Taakstraf_ | _boete_   |
| --------------------------- | ---------- | ----------- | --------- |
| **Eerste Veroordeling**     | 21 maanden |             | € 6.800,- |
| **Tweede Veroordeling**     | 37 maanden |             | € 8.500,- |
| **Meerdere Veroordelingen** | 49 maanden |             | € 9.350,- |

# Artikel T-V 2 - Vuurwapens en Explosieven (26 WWM)

1. Strafbaar is een persoon die een vuurwapen voorhanden heeft, bij zich draagt, opgeslagen heeft op een plaats of in de laadruimte heeft van zijn of haar vervoersmiddel.
2. Onderscheid wordt gemaakt tussen:
   * Cat. 1 Kleinevuurwapens zijnde; alle vuurwapens welke niet apart zijn benoemt onder cat 2.
   * Cat. 2 Automatische vuurwapens, shutgun, explosieven, granaten, thermiet, rocketlauncher.

| _**`Categorie 1`**_         | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 45 maanden |             | € 10.000,- |
| **Tweede Veroordeling**     | 63 maanden |             | € 12.500,- |
| **Meerdere Veroordelingen** | 81 maanden |             | € 15.500,- |

| _**`Categorie 2`**_         | _Celstraf_  | _Taakstraf_ | _boete_    |
| --------------------------- | ----------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 81 maanden  |             | € 20.000,- |
| **Tweede Veroordeling**     | 108 maanden |             | € 25.000,- |
| **Meerdere Veroordelingen** | 144 maanden |             | € 27.500,- |

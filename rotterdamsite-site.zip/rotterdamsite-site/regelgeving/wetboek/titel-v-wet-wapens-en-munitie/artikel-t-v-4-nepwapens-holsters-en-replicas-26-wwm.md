# Artikel T-V 4 - Nepwapens, holsters en replica's (26 WWM)

1. Strafbaar is een persoon die een nepwapen of replica die, van dichtbij of op enige afstand, niet gemakkelijk van echt te onderscheiden is.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 9 maanden  |             | € 5000,-   |
| **Tweede Veroordeling**     | 18 maanden |             | € 7.500,-  |
| **Meerdere Veroordelingen** | 27 maanden |             | € 10.000,- |

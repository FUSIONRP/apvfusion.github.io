# Artikel T-V 5 - Wapenhandel (14-20 WWM)

1. Strafbaar is een persoon die wapens, aangemerkt als niet legaal, invoert, uitvoert, of overdraagd.
2. Indien aantoonbaar is dat een aanvraag is gedaan danwel een transactie is gepleegd of zou gaan worden, of dreigde te gaan worden, doch niet is afgerond, wordt dit aangemerkt als een poging tot wapenhandel.
3. Indien de politie ten tijde van het overdragen de wapenhandel stopt, wordt dit gezien als voltooid feit.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 18 maanden |             | € 25.000,- |
| **Tweede Veroordeling**     | 36 maanden |             | € 30.000,- |
| **Meerdere Veroordelingen** | 54 maanden |             | € 45.000,- |

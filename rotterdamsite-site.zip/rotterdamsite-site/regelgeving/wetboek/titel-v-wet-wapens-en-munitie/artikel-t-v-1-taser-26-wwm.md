# Artikel T-V 1 - Taser (26 WWM)

1. Strafbaar is een persoon die een stroomstootwapen voorhanden heeft, bij zich draagt, opgeslagen heeft op een plaats of in de laadruimte heeft van zijn of haar vervoersmiddel.
2. Wanneer het wapen is gebruikt in combinatie met een ander strafbaarfeit wordt de straf met 1/3 verhoogd.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     | 15 maanden |             | € 2500,-   |
| **Tweede Veroordeling**     | 25 maanden |             | € 5000,-   |
| **Meerdere Veroordelingen** | 35 maanden |             | € 10.000,- |

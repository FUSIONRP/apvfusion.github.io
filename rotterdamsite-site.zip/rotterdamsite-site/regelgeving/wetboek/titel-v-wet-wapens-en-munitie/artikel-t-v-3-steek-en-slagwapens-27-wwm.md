# Artikel T-V 3 - Steek- en slagwapens (27 WWM)

1. Strafbaar is een persoon die een steekwapen voorhanden heeft, bij zich draagt, opgeslagen heeft op een plaats of in de laadruimte heeft van zijn of haar vervoersmiddel, waarvan redelijkerwijs kan worden aangenomen dat deze bedoelt is om letsel toe te brengen.
2. Alle soorten steekwapens zijn verboden.
3. De 'Hamer' en 'bijl' vallen onder een steek- en/of slag wapen, indien de verdachte deze onder zich heeft tijdens een strafbaar feit.

|                             | _Celstraf_ | _Taakstraf_ | _boete_    |
| --------------------------- | ---------- | ----------- | ---------- |
| **Eerste Veroordeling**     |            |             | € 5.000,-  |
| **Tweede Veroordeling**     |            | 40 uur      | € 7.500,-  |
| **Meerdere Veroordelingen** | 13 maanden |             | € 10.000,- |
